# Open Jarvis Cybersecurity Tutor — feature notes

## What was added

- `app/src/main/java/com/openjarvis/cybersecurity/CybersecurityTutor.kt`: a reusable tutor system prompt, 12-stage curriculum, example prompts, and a cybersecurity-question classifier.
- A `Cybersecurity Tutor` category in the prompt library with beginner-friendly lesson prompts.

## Coverage

Networking, Linux basics, Python for defensive automation, web security and OWASP, Android APK/permission security, cryptography, identity/access management, vulnerability management, logging/SIEM, incident response, safe malware/phishing analysis, CTF/lab practice, cloud/API security, and responsible disclosure.

## Important implementation limit

This adds tutor resources to the source tree. It does **not** by itself create a fully wired chat screen or guarantee an exhaustive offline knowledge base. The current main `AgentCore` is designed to produce JSON device-action plans, not conversational answers; wiring a dedicated tutor chat UI to the configured AI provider is a separate integration step. The tutor prompt is designed for authorized learning and defensive work, not unauthorized intrusion.

## Safety

Use practical testing only on owned systems, systems with explicit permission, or purpose-built labs/CTFs. Do not run scans or commands automatically from this tutor. Any future command-execution integration should show the exact command, target, scope, and ask for confirmation before execution.
