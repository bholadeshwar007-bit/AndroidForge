package com.openjarvis.cybersecurity

/**
 * Prompt and curriculum resources for Open Jarvis's cybersecurity tutor.
 * This class deliberately does not execute shell commands or perform network scans.
 * A conversational UI can use systemInstructions() as its system prompt and
 * lessonPlan() to present a structured learning path.
 */
object CybersecurityTutor {
    const val MODE_ID = "cybersecurity_tutor"
    const val MODE_TITLE = "Cybersecurity Tutor"

    fun systemInstructions(): String = """
You are Open Jarvis Cybersecurity Tutor: a thorough, beginner-friendly cybersecurity
teacher. Explain in simple Hinglish or the user's language, define jargon, give safe
examples, and teach from fundamentals through advanced defensive practice.

CURRICULUM: networking (TCP/IP, DNS, HTTP/S, ports, routing, Wi-Fi); Linux and shell
basics; Python for defensive automation; web security (authentication, sessions,
access control, input validation, OWASP Top 10); Android security (permissions,
components, APK structure, signing, secure storage); cryptography fundamentals;
identity and access management; threat modelling; secure coding; logs/SIEM; incident
response; malware and phishing analysis in isolated labs; vulnerability management;
cloud and API security; privacy; CTFs and intentionally vulnerable training targets.

TEACHING FORMAT: (1) concept, (2) why it matters, (3) safe lab/demo, (4) commands only
when appropriate, explaining every flag, (5) expected output, (6) common mistakes,
(7) mitigation/detection, (8) short quiz and next step. Do not invent tool output.

AUTHORIZATION: Keep hands-on testing within systems the learner owns or has explicit
permission to test, or purpose-built CTF/lab environments. For real targets, help with
scope definition, defensive assessment, remediation, and responsible disclosure.
Do not provide operational instructions to steal credentials, evade detection, deploy
malware/ransomware, persist on devices, exfiltrate private data, bypass access controls
on third-party systems, or exploit a real target without authorization. Redirect such
requests to safe lab exercises, detection, or mitigation. Never initiate phone actions,
run commands, install tools, scan networks, or send data without explicit user approval.

Be comprehensive about cybersecurity knowledge; do not claim that this prompt itself
contains an exhaustive offline database. Use the configured AI provider's knowledge,
be transparent about uncertainty, and recommend checking current vendor documentation
for version-specific details.
""".trimIndent()

    data class Lesson(val title: String, val goal: String, val practice: String)

    val lessonPlan: List<Lesson> = listOf(
        Lesson("1. Computer and network basics", "Understand IP, MAC, DNS, TCP/UDP, ports, HTTP/S and routing.", "Inspect your own device's network settings and draw a simple request path."),
        Lesson("2. Linux and command line", "Learn files, permissions, processes, pipes and package management.", "Practice ls, pwd, cat, grep and chmod in a local test folder."),
        Lesson("3. Python for defenders", "Parse logs, validate input and automate repetitive checks.", "Write a script that counts failed logins in a sample log file."),
        Lesson("4. Web security", "Learn sessions, authentication, authorization, input validation and OWASP risks.", "Use a deliberately vulnerable local training app and document a fix."),
        Lesson("5. Android security", "Understand APKs, app signing, permissions, exported components and secure storage.", "Review permissions and manifest of your own sample APK."),
        Lesson("6. Cryptography and identity", "Understand hashing vs encryption, TLS, MFA, keys and least privilege.", "Compare password hashing concepts and configure MFA on your own account."),
        Lesson("7. Vulnerability assessment", "Understand CVEs, severity, patching, asset inventory and safe verification.", "Review a lab asset list and write a remediation-priority table."),
        Lesson("8. Detection and incident response", "Learn logs, indicators, containment, recovery and evidence handling.", "Analyze a supplied sample log and create a timeline."),
        Lesson("9. Malware and phishing analysis", "Recognize suspicious behavior and analyze samples safely without executing them.", "Inspect a harmless example email and list indicators and mitigations."),
        Lesson("10. CTF and authorized labs", "Practice reconnaissance and exploitation concepts only in intentionally vulnerable labs.", "Choose a beginner CTF target and define scope before testing."),
        Lesson("11. Cloud and API security", "Learn IAM, secrets management, API auth, rate limiting and audit logs.", "Threat-model a toy API and recommend controls."),
        Lesson("12. Reporting and responsible disclosure", "Communicate impact, reproducibility, evidence and remediation clearly.", "Write a mock finding with scope, impact, safe reproduction and fix.")
    )

    val examplePrompts: List<String> = listOf(
        "Teach me ethical hacking from zero in Hinglish, one lesson at a time.",
        "Explain IP addresses, ports, DNS and TCP/UDP with safe examples.",
        "Teach Kali Linux commands for a local practice lab and explain every command.",
        "Show me how to set up an isolated cybersecurity lab safely.",
        "Explain OWASP Top 10 and how developers prevent each class of bug.",
        "Help me audit permissions and security risks in my own Android APK.",
        "Teach phishing detection and how to analyze a suspicious email safely.",
        "Analyze this sample security log and identify possible brute-force indicators.",
        "Give me a beginner CTF exercise with hints, not a real-world target.",
        "Help me write a professional vulnerability report and remediation plan."
    )

    fun isCybersecurityQuestion(text: String): Boolean {
        val q = text.lowercase()
        val terms = listOf(
            "cybersecurity", "cyber security", "ethical hacking", "kali linux", "penetration test",
            "pentest", "network security", "owasp", "vulnerability", "malware analysis",
            "phishing", "ctf", "android security", "nmap", "metasploit", "burp suite"
        )
        return terms.any(q::contains)
    }
}
