package com.openjarvis.agent

import android.content.Context

/** Conservative local policy for actions proposed by an LLM. Default is deny. */
class ActionPolicy(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun isTrusted(packageName: String?): Boolean =
        !packageName.isNullOrBlank() && trustedPackages().contains(packageName)

    fun trustedPackages(): Set<String> = prefs.getStringSet(KEY_TRUSTED, mutableSetOf())?.toSet() ?: emptySet()

    fun setTrusted(packageName: String, trusted: Boolean) {
        val next = trustedPackages().toMutableSet()
        if (trusted) next.add(packageName) else next.remove(packageName)
        prefs.edit().putStringSet(KEY_TRUSTED, next.toMutableSet()).apply()
    }

    fun needsConfirmation(action: Action, packageName: String?): Boolean {
        val pkg = packageName.orEmpty()
        if (pkg in FINANCIAL_PACKAGES) return true
        return when (action.action) {
            Action.TYPE, Action.CLEAR_TYPE -> pkg in MESSAGING_PACKAGES || pkg in FINANCIAL_PACKAGES
            Action.AI_PROMPT, Action.TAP_COORDS, Action.SCREENSHOT, Action.READ_SCREEN, Action.EXTRACT_TEXT -> true
            Action.TAP, Action.LONG_PRESS -> {
                val target = (action.text ?: action.hint ?: "").lowercase()
                RISKY_WORDS.any { target.contains(it) }
            }
            else -> false
        }
    }

    companion object {
        const val PREFS = "jarvis_action_policy"
        const val KEY_TRUSTED = "trusted_packages"
        val KNOWN_APPS = listOf(
            "YouTube" to "com.google.android.youtube",
            "WhatsApp" to "com.whatsapp",
            "Chrome" to "com.android.chrome",
            "Messages" to "com.google.android.apps.messaging",
            "Telegram" to "org.telegram.messenger",
            "Instagram" to "com.instagram.android",
            "Phone" to "com.google.android.dialer",
            "Settings" to "com.android.settings",
            "Paytm" to "net.one97.paytm",
            "PhonePe" to "com.phonepe.app",
            "Google Wallet" to "com.google.android.apps.wallet"
        )
        private val MESSAGING_PACKAGES = setOf(
            "com.whatsapp", "com.google.android.apps.messaging", "org.telegram.messenger",
            "com.instagram.android", "com.facebook.orca", "com.discord"
        )
        private val FINANCIAL_PACKAGES = setOf(
            "com.google.android.apps.wallet", "com.google.android.apps.walletnfcrel",
            "net.one97.paytm", "com.paytm.android", "com.phonepe.app", "com.phonepe", "com.razorpay"
        )
        private val RISKY_WORDS = listOf(
            "send", "pay", "transfer", "delete", "remove", "post", "purchase", "buy",
            "confirm", "submit", "share", "publish", "call", "place order", "accept"
        )
    }
}
