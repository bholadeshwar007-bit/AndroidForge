package com.openjarvis.agent

import android.app.Activity
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class ActionConfirmationActivity : ComponentActivity() {
    private var resolved = false
    private var requestId: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestId = intent.getStringExtra(EXTRA_ID)
        val title = intent.getStringExtra(EXTRA_TITLE) ?: "Confirm action"
        val details = intent.getStringExtra(EXTRA_DETAILS) ?: "Open Jarvis wants to perform an action."
        setContent {
            MaterialTheme {
                ApprovalDialog(title, details,
                    onApprove = { resolve(true) },
                    onDeny = { resolve(false) })
            }
        }
    }

    private fun resolve(approved: Boolean) {
        if (resolved) return
        resolved = true
        ActionApprovalGate.resolve(requestId, approved)
        finish()
    }

    override fun onBackPressed() {
        resolve(false)
    }

    override fun onDestroy() {
        if (!resolved) ActionApprovalGate.resolve(requestId, false)
        super.onDestroy()
    }

    companion object {
        const val EXTRA_ID = "approval_id"
        const val EXTRA_TITLE = "approval_title"
        const val EXTRA_DETAILS = "approval_details"
    }
}

@Composable
private fun ApprovalDialog(title: String, details: String, onApprove: () -> Unit, onDeny: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDeny,
        title = { Text("Allow this action?") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(title)
                Text(details)
                Text("Only approve if you recognize this action. No response means it is denied.")
            }
        },
        confirmButton = { Button(onClick = onApprove) { Text("Allow once") } },
        dismissButton = { OutlinedButton(onClick = onDeny) { Text("Cancel") } }
    )
}
