package com.openjarvis.agent

import android.content.Context
import android.content.Intent
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.withTimeoutOrNull
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

/** In-process, one-action approval. No approval means deny. */
object ActionApprovalGate {
    private val pending = ConcurrentHashMap<String, CompletableDeferred<Boolean>>()

    suspend fun request(context: Context, title: String, details: String): Boolean {
        val id = UUID.randomUUID().toString()
        val deferred = CompletableDeferred<Boolean>()
        pending[id] = deferred
        try {
            context.startActivity(Intent(context, ActionConfirmationActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                putExtra(ActionConfirmationActivity.EXTRA_ID, id)
                putExtra(ActionConfirmationActivity.EXTRA_TITLE, title.take(180))
                putExtra(ActionConfirmationActivity.EXTRA_DETAILS, details.take(500))
            })
            return withTimeoutOrNull(60_000L) { deferred.await() } ?: false
        } catch (_: Exception) {
            return false
        } finally {
            pending.remove(id)
        }
    }

    fun resolve(id: String?, approved: Boolean) {
        if (!id.isNullOrBlank()) pending[id]?.complete(approved)
    }
}
