# Open Jarvis privacy-controlled source changes (not a release APK)

## Implemented in this source tree
- Added an explicit Android `INTERNET` permission for cloud-provider requests (hybrid mode needs network access).
- Added a `Hybrid (Local first)` provider option. It attempts the existing local Llama endpoint when the project says a model is loaded, then falls back to Groq using the API key saved in Settings.
- Added a default-deny trusted-app allowlist in Settings. App interactions are blocked until the user enables the target app.
- Added a one-action Allow once / Cancel approval activity. Sensitive operations (messaging text entry, financial apps, risky tap words, coordinates, screen reads, screenshots, extraction, and AI-app delegation) require confirmation.
- Added a one-time consent prompt before screen OCR/task memory can be included in a cloud-capable provider request. If denied, screen text and memory context are omitted from that request.
- Disabled startup of the legacy TCP bridge. Its old caller check compared `Process.myUid()` (the app's own UID), not the connecting client's UID. The bridge is now fail-closed and binds loopback if manually started.
- Fixed an apparent `ModelManager` state-name compile error (`ModelStateLoaded` -> `ModelState.Loaded`) and fixed Settings' provider-save callback so it saves the selected provider instead of always saving Groq.
- Added package visibility query for launcher apps.

## Important limitations / remaining risks
- This is **source code only**, not a built or tested APK. No claim of fully secure or APK-ready status is made.
- No Gradle wrapper is present in the original ZIP, and no Gradle executable/Android SDK build environment was available in this session, so Android compilation and device tests were not run.
- The existing local model code is incomplete: `ModelManager.loadModel()` changes state but does not start an inference runtime, while `LlamaProvider` expects an HTTP endpoint at `localhost:8080`. Therefore local-first inference may fail and fall back to Groq; a real on-device inference engine/server still needs to be integrated and tested.
- Hybrid fallback is currently Groq-specific. A valid Groq API key and internet connection are required whenever local inference is unavailable. The command itself still goes to the cloud in fallback mode; the consent prompt only controls screen OCR and recent-task memory.
- The consent activity is an initial implementation and must be tested on-device, including background-start restrictions, timeout/cancel behavior, accessibility interactions, and Android versions.
- Accessibility permission is powerful: the service can read screen content and interact with apps. The allowlist is an application-level guard, not a substitute for Android permissions or a security audit.
- `ActionPolicy` uses package names and text heuristics to identify risky actions. UI changes, localized button labels, or new apps can bypass heuristic classification; sensitive actions need broader testing and a stronger action schema.
- Voice recognition may use Android's configured speech service and may send audio to that service. Offline speech recognition is not guaranteed by these changes.
- Cloud provider requests use TLS for HTTPS endpoints, but provider-side retention and processing depend on the provider's policies.

## Build requirements
- Android Studio or Gradle 8.2-compatible setup, JDK 17, Android SDK Platform 34, and Android build-tools.
- Add a Gradle wrapper from a trusted Gradle distribution before building; do not execute arbitrary wrapper binaries from an unknown archive.
- Build debug first, inspect merged manifest/dependencies, then run unit/instrumentation tests and test on a spare device before enabling Accessibility.


## Dual AI mode update (2026-10-24)
- Added a Settings selector for Filtered AI / Unfiltered AI; choice is stored in local SharedPreferences.
- AgentCore adds a response-style instruction for the selected mode. This affects only the device-action planning prompt; it does not remove provider-side rules or the ActionPolicy confirmation gates.
- Image generation is NOT implemented in this repository: no image-generation provider/client/UI was found in source scan. It requires a separately selected compatible service/model and privacy consent before sending prompts/images online.
- Not built or runtime-tested in this environment. Do not treat this ZIP as a verified APK or as fully secure.
