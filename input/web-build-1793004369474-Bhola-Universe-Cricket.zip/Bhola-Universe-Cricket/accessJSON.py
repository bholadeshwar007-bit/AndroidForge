import json
import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
with open(os.path.join(BASE_DIR, "data", "playerInfoProcessed.json"), encoding="utf-8") as f:
	data = json.load(f)

def getPlayerInfo(initials):
	# fetch = document.find_one({"playerInitials": initials})
	fetch = data[initials] #may be same for some

	return fetch 