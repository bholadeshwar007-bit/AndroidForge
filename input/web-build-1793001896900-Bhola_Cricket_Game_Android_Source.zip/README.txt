BHOLA CRICKET GAME — ANDROID SOURCE PROJECT

This is an Android Studio/Gradle source project that wraps the included HTML cricket prototype in an Android WebView.

Project contents:
- app/src/main/assets/index.html: browser cricket prototype
- MainActivity.kt: Android WebView launcher
- AndroidManifest.xml and Gradle build files

Important:
- This ZIP is an Android source project, not a ready-made APK.
- A compatible build service must support Android Gradle projects and Kotlin.
- If the build service only accepts a different project format, this ZIP may not work there.
- Test the resulting APK before publishing. This prototype is not a full 3D cricket game.
